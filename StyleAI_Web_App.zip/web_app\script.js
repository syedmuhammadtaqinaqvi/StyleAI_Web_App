// Fashion Stylist App JavaScript
class StyleAIApp {
    constructor() {
        this.wardrobeItems = [];
        this.weatherData = null;
        this.recommendations = [];
        
        this.init();
    }

    init() {
        this.setupEventListeners();
        this.setupFileUpload();
        this.loadSampleWardrobe();
        this.getWeatherData();
        this.setupScrollEffects();
    }

    setupEventListeners() {
        // Navigation smooth scrolling
        document.querySelectorAll('.nav-link').forEach(link => {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                const targetId = link.getAttribute('href').substring(1);
                this.scrollToSection(targetId);
            });
        });

        // Mobile navigation toggle
        const navToggle = document.querySelector('.nav-toggle');
        const navMenu = document.querySelector('.nav-menu');
        
        if (navToggle && navMenu) {
            navToggle.addEventListener('click', () => {
                navMenu.classList.toggle('active');
            });
        }
    }

    setupFileUpload() {
        const fileInput = document.getElementById('fileInput');
        const uploadBox = document.getElementById('uploadBox');
        const wardrobeGrid = document.getElementById('wardrobeGrid');

        // File input change event
        fileInput.addEventListener('change', (e) => {
            this.handleFileUpload(e.target.files);
        });

        // Drag and drop events
        uploadBox.addEventListener('dragover', (e) => {
            e.preventDefault();
            uploadBox.style.borderColor = '#764ba2';
            uploadBox.style.backgroundColor = 'rgba(118, 75, 162, 0.1)';
        });

        uploadBox.addEventListener('dragleave', (e) => {
            e.preventDefault();
            uploadBox.style.borderColor = '#667eea';
            uploadBox.style.backgroundColor = 'rgba(102, 126, 234, 0.05)';
        });

        uploadBox.addEventListener('drop', (e) => {
            e.preventDefault();
            uploadBox.style.borderColor = '#667eea';
            uploadBox.style.backgroundColor = 'rgba(102, 126, 234, 0.05)';
            
            const files = e.dataTransfer.files;
            this.handleFileUpload(files);
        });
    }

    handleFileUpload(files) {
        Array.from(files).forEach((file, index) => {
            if (file.type.startsWith('image/')) {
                const reader = new FileReader();
                reader.onload = (e) => {
                    const wardrobeItem = {
                        id: Date.now() + index,
                        name: this.generateClothingName(file.name),
                        type: this.detectClothingType(file.name),
                        color: this.detectColor(),
                        image: e.target.result,
                        uploadDate: new Date().toISOString()
                    };
                    
                    this.wardrobeItems.push(wardrobeItem);
                    this.displayWardrobeItem(wardrobeItem);
                };
                reader.readAsDataURL(file);
            }
        });
    }

    generateClothingName(filename) {
        const types = ['Shirt', 'Dress', 'Pants', 'Jacket', 'Skirt', 'Blouse', 'Sweater', 'Jeans'];
        return types[Math.floor(Math.random() * types.length)];
    }

    detectClothingType(filename) {
        const name = filename.toLowerCase();
        if (name.includes('shirt') || name.includes('top')) return 'top';
        if (name.includes('pants') || name.includes('jeans')) return 'bottom';
        if (name.includes('dress')) return 'dress';
        if (name.includes('jacket') || name.includes('coat')) return 'outerwear';
        if (name.includes('shoe')) return 'shoes';
        return 'accessory';
    }

    detectColor() {
        const colors = ['Red', 'Blue', 'Green', 'Black', 'White', 'Navy', 'Beige', 'Brown', 'Gray', 'Pink'];
        return colors[Math.floor(Math.random() * colors.length)];
    }

    displayWardrobeItem(item) {
        const wardrobeGrid = document.getElementById('wardrobeGrid');
        const itemElement = document.createElement('div');
        itemElement.className = 'wardrobe-item';
        itemElement.innerHTML = `
            <img src="${item.image}" alt="${item.name}">
            <div class="wardrobe-item-info">
                <h4>${item.name}</h4>
                <p>${item.color} ${item.type}</p>
                <button class="btn btn-outline btn-sm" onclick="styleAI.removeWardrobeItem('${item.id}')">
                    <i class="fas fa-trash"></i>
                </button>
            </div>
        `;
        
        itemElement.style.opacity = '0';
        itemElement.style.transform = 'translateY(20px)';
        
        wardrobeGrid.appendChild(itemElement);
        
        setTimeout(() => {
            itemElement.style.opacity = '1';
            itemElement.style.transform = 'translateY(0)';
            itemElement.style.transition = 'all 0.5s ease';
        }, 100);
    }

    removeWardrobeItem(itemId) {
        this.wardrobeItems = this.wardrobeItems.filter(item => item.id !== itemId);
        this.renderWardrobe();
    }

    renderWardrobe() {
        const wardrobeGrid = document.getElementById('wardrobeGrid');
        wardrobeGrid.innerHTML = '';
        this.wardrobeItems.forEach(item => {
            this.displayWardrobeItem(item);
        });
    }

    loadSampleWardrobe() {
        // Add some sample wardrobe items for demonstration
        const sampleItems = [
            {
                id: '1',
                name: 'White Button Shirt',
                type: 'top',
                color: 'White',
                image: 'https://images.unsplash.com/photo-1596755094514-f87e34085b2c?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=400&q=80'
            },
            {
                id: '2',
                name: 'Dark Jeans',
                type: 'bottom',
                color: 'Blue',
                image: 'https://images.unsplash.com/photo-1542272604-787c3835535d?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=400&q=80'
            },
            {
                id: '3',
                name: 'Blazer',
                type: 'outerwear',
                color: 'Navy',
                image: 'https://images.unsplash.com/photo-1594633312681-425c7b97ccd1?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=400&q=80'
            }
        ];

        this.wardrobeItems = sampleItems;
        setTimeout(() => {
            sampleItems.forEach(item => this.displayWardrobeItem(item));
        }, 1000);
    }

    async getWeatherData() {
        try {
            // Try to get user's location
            if (navigator.geolocation) {
                navigator.geolocation.getCurrentPosition(
                    (position) => {
                        const lat = position.coords.latitude;
                        const lon = position.coords.longitude;
                        this.fetchWeatherByCoords(lat, lon);
                    },
                    (error) => {
                        console.log('Geolocation error:', error);
                        this.fetchWeatherByCity('London'); // Default city
                    }
                );
            } else {
                this.fetchWeatherByCity('London'); // Default city
            }
        } catch (error) {
            console.log('Weather data unavailable, using default values');
            this.useDefaultWeather();
        }
    }

    async fetchWeatherByCoords(lat, lon) {
        const apiKey = 'your-api-key-here'; // Replace with actual OpenWeatherMap API key
        const url = `https://api.openweathermap.org/data/2.5/weather?lat=${lat}&lon=${lon}&appid=${apiKey}&units=metric`;
        
        try {
            const response = await fetch(url);
            if (response.ok) {
                const data = await response.json();
                this.processWeatherData(data);
            } else {
                this.useDefaultWeather();
            }
        } catch (error) {
            console.log('Weather API error:', error);
            this.useDefaultWeather();
        }
    }

    async fetchWeatherByCity(city) {
        const apiKey = 'your-api-key-here'; // Replace with actual OpenWeatherMap API key
        const url = `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${apiKey}&units=metric`;
        
        try {
            const response = await fetch(url);
            if (response.ok) {
                const data = await response.json();
                this.processWeatherData(data);
            } else {
                this.useDefaultWeather();
            }
        } catch (error) {
            console.log('Weather API error:', error);
            this.useDefaultWeather();
        }
    }

    processWeatherData(data) {
        this.weatherData = {
            temperature: Math.round(data.main.temp),
            condition: this.mapWeatherCondition(data.weather[0].main, data.weather[0].icon),
            location: `${data.name}, ${data.sys.country}`,
            humidity: data.main.humidity,
            windSpeed: Math.round(data.wind.speed * 3.6), // Convert m/s to km/h
            description: data.weather[0].description
        };
        
        this.updateWeatherDisplay();
    }

    mapWeatherCondition(main, icon) {
        const conditionMap = {
            'Clear': { name: 'Sunny', icon: 'fas fa-sun' },
            'Clouds': { name: 'Cloudy', icon: 'fas fa-cloud' },
            'Rain': { name: 'Rainy', icon: 'fas fa-cloud-rain' },
            'Drizzle': { name: 'Rainy', icon: 'fas fa-cloud-rain' },
            'Thunderstorm': { name: 'Stormy', icon: 'fas fa-bolt' },
            'Snow': { name: 'Snowy', icon: 'fas fa-snowflake' },
            'Mist': { name: 'Misty', icon: 'fas fa-smog' },
            'Fog': { name: 'Foggy', icon: 'fas fa-smog' }
        };
        
        return conditionMap[main] || { name: 'Clear', icon: 'fas fa-sun' };
    }

    useDefaultWeather() {
        this.weatherData = {
            temperature: Math.floor(Math.random() * 30) + 10,
            condition: this.getRandomWeatherCondition(),
            location: 'Your Location',
            humidity: Math.floor(Math.random() * 100),
            windSpeed: Math.floor(Math.random() * 20)
        };
        
        this.updateWeatherDisplay();
    }

    getRandomWeatherCondition() {
        const conditions = [
            { name: 'Sunny', icon: 'fas fa-sun' },
            { name: 'Cloudy', icon: 'fas fa-cloud' },
            { name: 'Rainy', icon: 'fas fa-cloud-rain' },
            { name: 'Snowy', icon: 'fas fa-snowflake' },
            { name: 'Windy', icon: 'fas fa-wind' }
        ];
        
        return conditions[Math.floor(Math.random() * conditions.length)];
    }

    updateWeatherDisplay() {
        if (!this.weatherData) return;

        const tempElement = document.getElementById('currentTemp');
        const descElement = document.getElementById('weatherDescription');
        const locationElement = document.getElementById('weatherLocation');
        const iconElement = document.querySelector('.weather-icon i');
        const suggestionsElement = document.getElementById('weatherSuggestions');

        if (tempElement) tempElement.textContent = `${this.weatherData.temperature}°C`;
        if (descElement) descElement.textContent = this.weatherData.condition.name;
        if (locationElement) locationElement.textContent = this.weatherData.location;
        if (iconElement) {
            iconElement.className = this.weatherData.condition.icon;
        }

        // Update weather-based suggestions
        const suggestions = this.getWeatherSuggestions();
        if (suggestionsElement) {
            suggestionsElement.innerHTML = suggestions.map(s => `<li>${s}</li>`).join('');
        }
    }

    getWeatherSuggestions() {
        if (!this.weatherData) return [];

        const { condition, temperature } = this.weatherData;
        const suggestions = [];

        switch (condition.name.toLowerCase()) {
            case 'sunny':
                suggestions.push('Light cotton fabrics recommended');
                suggestions.push("Don't forget sunglasses");
                suggestions.push('Perfect weather for bright colors');
                break;
            case 'rainy':
                suggestions.push('Waterproof jacket essential');
                suggestions.push('Closed-toe shoes recommended');
                suggestions.push('Darker colors to hide stains');
                break;
            case 'cloudy':
                suggestions.push('Perfect for layering');
                suggestions.push('Light jacket might be useful');
                suggestions.push('Great weather for any color');
                break;
            case 'snowy':
                suggestions.push('Heavy coat and warm layers');
                suggestions.push('Waterproof boots necessary');
                suggestions.push('Add gloves and scarves');
                break;
            default:
                suggestions.push('Check the weather before heading out');
                suggestions.push('Layer clothing for comfort');
                suggestions.push('Choose versatile pieces');
        }

        if (temperature < 15) {
            suggestions.push('Warm clothing recommended');
        } else if (temperature > 25) {
            suggestions.push('Light, breathable fabrics ideal');
        }

        return suggestions;
    }

    generateRecommendations() {
        const occasion = document.getElementById('occasion').value;
        const weather = document.getElementById('weather').value;
        const location = document.getElementById('location').value;
        const timeOfDay = document.getElementById('timeOfDay').value;

        if (!occasion) {
            this.showNotification('Please select an occasion', 'warning');
            return;
        }

        // Show loading state
        const btn = document.querySelector('.btn-primary.btn-large');
        const originalText = btn.innerHTML;
        btn.innerHTML = '<span class="loading"></span> Generating Recommendations...';
        btn.disabled = true;

        // Simulate AI processing time
        setTimeout(() => {
            this.recommendations = this.createRecommendations(occasion, weather, timeOfDay);
            this.displayRecommendations();
            
            // Reset button
            btn.innerHTML = originalText;
            btn.disabled = false;
        }, 2000);
    }

    createRecommendations(occasion, weather, timeOfDay) {
        const recommendations = [];
        
        // Generate 3 different outfit recommendations
        for (let i = 0; i < 3; i++) {
            const outfit = {
                id: i + 1,
                title: this.generateOutfitTitle(occasion, i),
                items: this.generateOutfitItems(occasion, weather, timeOfDay),
                confidence: Math.floor(Math.random() * 20) + 80,
                description: this.generateOutfitDescription(occasion)
            };
            recommendations.push(outfit);
        }

        return recommendations;
    }

    generateOutfitTitle(occasion, index) {
        const titles = {
            work: ['Professional Power Look', 'Business Casual Chic', 'Executive Style'],
            casual: ['Weekend Vibes', 'Casual Cool', 'Relaxed Elegance'],
            formal: ['Black Tie Elegance', 'Formal Sophistication', 'Evening Glamour'],
            party: ['Party Ready', 'Night Out Look', 'Social Butterfly'],
            date: ['Date Night Magic', 'Romantic Charm', 'Dinner Date Style'],
            gym: ['Workout Ready', 'Fitness Fashion', 'Active Style'],
            travel: ['Travel Comfort', 'Airport Chic', 'Journey Style']
        };

        return titles[occasion] ? titles[occasion][index] : 'Stylish Look';
    }

    generateOutfitItems(occasion, weather, timeOfDay) {
        const items = [];
        
        // Base items by occasion
        const occasionItems = {
            work: ['Blazer', 'Dress Shirt', 'Trousers', 'Dress Shoes', 'Watch'],
            casual: ['T-Shirt', 'Jeans', 'Sneakers', 'Sunglasses', 'Casual Jacket'],
            formal: ['Suit Jacket', 'Dress Shirt', 'Dress Pants', 'Formal Shoes', 'Tie'],
            party: ['Statement Top', 'Dark Jeans', 'Heels', 'Statement Jewelry', 'Clutch'],
            date: ['Nice Blouse', 'Skirt', 'Heels', 'Cardigan', 'Accessories'],
            gym: ['Athletic Top', 'Leggings', 'Sneakers', 'Sports Bra', 'Water Bottle'],
            travel: ['Comfortable Top', 'Comfortable Pants', 'Walking Shoes', 'Light Jacket', 'Backpack']
        };

        const baseItems = occasionItems[occasion] || occasionItems.casual;
        items.push(...baseItems.slice(0, 4));

        // Add weather-specific items
        if (weather === 'rainy' || weather === 'cold') {
            items.push('Jacket');
        }
        if (weather === 'sunny') {
            items.push('Sunglasses');
        }

        return items;
    }

    generateOutfitDescription(occasion) {
        const descriptions = {
            work: 'Perfect for making a professional impression while staying comfortable throughout your workday.',
            casual: 'Effortlessly stylish for your everyday activities and weekend adventures.',
            formal: 'Elegant and sophisticated for special occasions and formal events.',
            party: 'Stand out from the crowd with this fun and fashionable party outfit.',
            date: 'Romantic and charming, perfect for creating lasting memories.',
            gym: 'Functional and fashionable activewear for your fitness routine.',
            travel: 'Comfortable and practical while maintaining your style on the go.'
        };

        return descriptions[occasion] || 'A versatile and stylish outfit choice.';
    }

    displayRecommendations() {
        const displayElement = document.getElementById('recommendationsDisplay');
        const gridElement = document.getElementById('outfitGrid');

        gridElement.innerHTML = '';

        this.recommendations.forEach(outfit => {
            const outfitCard = document.createElement('div');
            outfitCard.className = 'outfit-card';
            outfitCard.innerHTML = `
                <h4 class="outfit-title">${outfit.title}</h4>
                <div class="outfit-items">
                    ${outfit.items.map(item => `<span class="outfit-item">${item}</span>`).join('')}
                </div>
                <p>${outfit.description}</p>
                <div class="outfit-confidence">
                    Confidence: ${outfit.confidence}%
                </div>
                <button class="btn btn-secondary mt-2" onclick="styleAI.saveOutfit(${outfit.id})">
                    <i class="fas fa-heart"></i> Save Outfit
                </button>
            `;
            
            outfitCard.style.opacity = '0';
            outfitCard.style.transform = 'translateY(20px)';
            gridElement.appendChild(outfitCard);
            
            setTimeout(() => {
                outfitCard.style.opacity = '1';
                outfitCard.style.transform = 'translateY(0)';
                outfitCard.style.transition = 'all 0.5s ease';
            }, outfit.id * 200);
        });

        displayElement.style.display = 'block';
        this.scrollToSection('recommendationsDisplay');
    }

    saveOutfit(outfitId) {
        const outfit = this.recommendations.find(r => r.id === outfitId);
        if (outfit) {
            this.showNotification(`"${outfit.title}" saved to your favorites!`, 'success');
        }
    }

    getWeatherRecommendations() {
        if (!this.weatherData) {
            this.showNotification('Weather data not available', 'warning');
            return;
        }

        // Auto-fill the weather field and generate recommendations
        document.getElementById('weather').value = this.weatherData.condition.name.toLowerCase();
        document.getElementById('occasion').value = 'casual';
        
        this.generateRecommendations();
    }

    scrollToSection(sectionId) {
        const element = document.getElementById(sectionId);
        if (element) {
            const navHeight = document.querySelector('.navbar').offsetHeight;
            const elementTop = element.offsetTop - navHeight - 20;
            
            window.scrollTo({
                top: elementTop,
                behavior: 'smooth'
            });
        }
    }

    setupScrollEffects() {
        // Add scroll effects for animations
        const observerOptions = {
            threshold: 0.1,
            rootMargin: '0px 0px -50px 0px'
        };

        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.style.opacity = '1';
                    entry.target.style.transform = 'translateY(0)';
                }
            });
        }, observerOptions);

        // Observe elements with animation classes
        document.querySelectorAll('.feature-card, .outfit-card, .wardrobe-item').forEach(el => {
            el.style.opacity = '0';
            el.style.transform = 'translateY(30px)';
            el.style.transition = 'all 0.6s ease';
            observer.observe(el);
        });
    }

    showNotification(message, type = 'info') {
        const notification = document.createElement('div');
        notification.className = `notification ${type}`;
        notification.style.cssText = `
            position: fixed;
            top: 100px;
            right: 20px;
            background: ${type === 'success' ? '#27ae60' : type === 'warning' ? '#f39c12' : '#667eea'};
            color: white;
            padding: 1rem 2rem;
            border-radius: 10px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
            z-index: 10000;
            transform: translateX(100%);
            transition: transform 0.3s ease;
        `;
        notification.textContent = message;
        
        document.body.appendChild(notification);
        
        setTimeout(() => {
            notification.style.transform = 'translateX(0)';
        }, 100);
        
        setTimeout(() => {
            notification.style.transform = 'translateX(100%)';
            setTimeout(() => {
                document.body.removeChild(notification);
            }, 300);
        }, 3000);
    }
}

// Global functions for HTML onclick events
function scrollToSection(sectionId) {
    styleAI.scrollToSection(sectionId);
}

function generateRecommendations() {
    styleAI.generateRecommendations();
}

function getWeatherRecommendations() {
    styleAI.getWeatherRecommendations();
}

// Initialize the app
let styleAI;
document.addEventListener('DOMContentLoaded', () => {
    styleAI = new StyleAIApp();
});

// Mobile Navigation Toggle
document.addEventListener('DOMContentLoaded', function() {
    const navToggle = document.querySelector('.nav-toggle');
    const navMenu = document.querySelector('.nav-menu');

    if (navToggle) {
        navToggle.addEventListener('click', function() {
            navMenu.classList.toggle('mobile-active');
        });
    }
});

// Add mobile styles for navigation
const mobileNavStyles = `
    @media (max-width: 768px) {
        .nav-menu {
            position: fixed;
            top: 80px;
            right: -300px;
            width: 250px;
            height: calc(100vh - 80px);
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(20px);
            flex-direction: column;
            padding: 2rem 1rem;
            box-shadow: -10px 0 30px rgba(0, 0, 0, 0.1);
            transition: right 0.3s ease;
            z-index: 999;
        }
        
        .nav-menu.mobile-active {
            right: 0;
        }
        
        .nav-link {
            padding: 1rem 0;
            border-bottom: 1px solid rgba(0, 0, 0, 0.1);
            width: 100%;
        }
    }
`;

// Inject mobile styles
const styleSheet = document.createElement('style');
styleSheet.textContent = mobileNavStyles;
document.head.appendChild(styleSheet);
