// Authentication JavaScript
function switchToSignup() {
    const loginForm = document.getElementById('loginForm');
    const signupForm = document.getElementById('signupForm');
    loginForm.style.display = 'none';
    signupForm.style.display = 'block';
}

function switchToLogin() {
    const loginForm = document.getElementById('loginForm');
    const signupForm = document.getElementById('signupForm');
    signupForm.style.display = 'none';
    loginForm.style.display = 'block';
}

function togglePassword(id) {
    const input = document.getElementById(id);
    if (input.type === 'password') {
        input.type = 'text';
    } else {
        input.type = 'password';
    }
}

function validatePasswordStrength(password) {
    const strengthIndicator = document.getElementById('passwordStrength');
    strengthIndicator.textContent = '';
    if (!password) return;

    const strongRegex = new RegExp("^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.{8,})");
    const mediumRegex = new RegExp("^(?=.*[a-z])(?=.*[A-Z])|(?=.*[a-z])(?=.*[0-9])|(?=.*[A-Z])(?=.*[0-9])");

    if (strongRegex.test(password)) {
        strengthIndicator.textContent = 'Strong';
        strengthIndicator.className = 'password-strength strong';
    } else if (mediumRegex.test(password)) {
        strengthIndicator.textContent = 'Medium';
        strengthIndicator.className = 'password-strength medium';
    } else {
        strengthIndicator.textContent = 'Weak';
        strengthIndicator.className = 'password-strength weak';
    }
}

// Detect password input changes for strength indication
const signupPasswordInput = document.getElementById('signupPassword');
signupPasswordInput.addEventListener('input', (e) => {
    validatePasswordStrength(e.target.value);
});

const signupFormElement = document.getElementById('signupFormElement');
signupFormElement.addEventListener('submit', (e) => {
    e.preventDefault();
    const password = document.getElementById('signupPassword').value;
    const confirmPassword = document.getElementById('confirmPassword').value;

    if (password !== confirmPassword) {
        alert('Passwords do not match.');
        return;
    }

    showLoadingOverlay();

    setTimeout(() => {
        // Simulate saving user data
        hideLoadingOverlay();
        alert('Account created successfully!');
        window.location.href = 'index.html';
    }, 2000);
});

const loginFormElement = document.getElementById('loginFormElement');
loginFormElement.addEventListener('submit', (e) => {
    e.preventDefault();
    alert('Sign in functionality not implemented yet.');
});

function showLoadingOverlay() {
    const loadingOverlay = document.getElementById('loadingOverlay');
    loadingOverlay.style.display = 'flex';
}

function hideLoadingOverlay() {
    const loadingOverlay = document.getElementById('loadingOverlay');
    loadingOverlay.style.display = 'none';
}
